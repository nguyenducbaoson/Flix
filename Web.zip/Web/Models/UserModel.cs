﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Web.Models
{
    public class UserModel
    {
        public string email { get; set;}
        public string fullname { get; set; }
        public string password { get; set; }
    }
}